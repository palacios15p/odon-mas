import Rutas from "./Rutas"

function App() {

  return (
    <Rutas />
  )
}

export default App
